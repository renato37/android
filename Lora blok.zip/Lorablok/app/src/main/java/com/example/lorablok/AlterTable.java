package com.example.lorablok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import hr.*;

public class AlterTable extends AppCompatActivity {
    Map<String, List<Integer>> mapa;
    int d;
    int sum = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alter_table);
        TableLayout tableLayout = new TableLayout(this);
        tableLayout = findViewById(R.id.tableLayout1);

        Bundle bundle = getIntent().getExtras();
        mapa = (Map<String, List<Integer>>)bundle.get("mapa");
        final int id = bundle.getInt("igra");
        final Igra igra = new Igra(id);
        TextView naslov = findViewById(R.id.textView);
        naslov.setText(igra.getNaziv());
        naslov.setTextSize(32);


        for(final String name: mapa.keySet()) {

            if (mapa.get(name) == null) {
                ArrayList<Integer> n = new ArrayList<Integer>();
                n.add(0);
                mapa.put(name, n);
            }

            if (mapa.get(name).size() <= id) {
                ArrayList<Integer> n = new ArrayList<Integer>();
                n = (ArrayList<Integer>) mapa.get(name);
                n.add(0);
                mapa.put(name, n);
            }

            TableRow tableRow = new TableRow(this);
            TextView textView = new TextView(this);
            textView.setTextSize(18);

            Button button = new Button(this);
            button.setText("+");

            final TextView amount = new TextView(this);
            amount.setTextSize(18);


            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int k = mapa.get(name).get(id);
                    k = k + igra.getNum();
                    sum += igra.getNum();
                    ArrayList<Integer> integ = (ArrayList<Integer>) mapa.get(name);
                    integ.set(id, k);
                    mapa.put(name, integ);
                    amount.setText(String.valueOf(mapa.get(name).get(id)));
                }
            });
            textView.setText(name);


            amount.setText(String.valueOf(mapa.get(name).get(id)));
            tableRow.addView(textView);
            tableRow.addView(amount);
            tableRow.addView(button);
            tableLayout.addView(tableRow);
        }
        Button ok = new Button(this);
        ok = findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sum <= igra.getMax() && sum >= igra.getMin()) {
                    Intent I = new Intent(AlterTable.this, MainTable.class);
                    I.putExtra("mapa", (Serializable) mapa);
                    startActivity(I);
                } else {
                    Toast.makeText(AlterTable.this, "Krivo uneseno", Toast.LENGTH_SHORT).show();
                    for (final String name : mapa.keySet()) {
                        ArrayList<Integer> n = new ArrayList<Integer>();
                        n = (ArrayList<Integer>) mapa.get(name);
                        n.set(id, 0);
                        sum = 0;
                        mapa.put(name, n);
                        Intent I = new Intent(AlterTable.this, AlterTable.class);
                        I.putExtra("mapa", (Serializable) mapa);
                        I.putExtra("igra", id);
                        startActivity(I);
                    }
                }
            }
        });

    }
}
