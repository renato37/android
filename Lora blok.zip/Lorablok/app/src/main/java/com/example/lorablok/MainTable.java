package com.example.lorablok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;

public class MainTable extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_table);

        Bundle bundle = getIntent().getExtras();
        final Map<String, List<Integer>> mapa = (Map<String, List<Integer>>)bundle.get("mapa");

        TableLayout tableLayout = new TableLayout(this);
        tableLayout = findViewById(R.id.tableLayout);
        TableRow tableRow = new TableRow(this);
        TableRow.LayoutParams params = new TableRow.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        tableRow.setLayoutParams(params);
        List<String> names = new ArrayList<>();

        TableLayout t1 = findViewById(R.id.rezultati);

        for(String name: mapa.keySet()){
            TextView textView = new TextView(this);
            textView.setText(name);
            textView.setGravity(1);
            textView.setTextSize(16);
            tableRow.addView(textView);
            names.add(name);
        }
        tableLayout.addView(tableRow);
        List<Integer> list1 = mapa.get(names.get(0));
        List<Integer> list2 = mapa.get(names.get(1));
        List<Integer> list3 = mapa.get(names.get(2));
        List<Integer> list4 = mapa.get(names.get(3));
        int sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0;
        int i = 0;
        if(list1 != null) {
            for (i = 0; i < list1.size(); i++) {
                if(i%7==3){
                    if(list1.get(i)==8){ list1.set(i, -8);}
                    if(list2.get(i)==8){ list2.set(i, -8);}
                    if(list3.get(i)==8){ list3.set(i, -8);}
                    if(list4.get(i)==8){ list4.set(i, -8);}
                }
                TableRow tableRow1 = new TableRow(this);
                TextView textView1 = new TextView(this);
                TextView textView2 = new TextView(this);
                TextView textView3 = new TextView(this);
                TextView textView4 = new TextView(this);
                textView1.setGravity(1);
                textView2.setGravity(1);
                textView3.setGravity(1);
                textView4.setGravity(1);
                textView1.setTextSize(18);
                textView2.setTextSize(18);
                textView3.setTextSize(18);
                textView4.setTextSize(18);
                textView1.setText(String.valueOf(list1.get(i)));
                tableRow1.addView(textView1);
                sum1+=list1.get(i);
                textView2.setText(String.valueOf(list2.get(i)));
                tableRow1.addView(textView2);
                sum2+=list2.get(i);
                textView3.setText(String.valueOf(list3.get(i)));
                tableRow1.addView(textView3);
                sum3+=list3.get(i);
                textView4.setText(String.valueOf(list4.get(i)));
                tableRow1.addView(textView4);
                sum4+=list4.get(i);
                tableLayout.addView(tableRow1);
                final int finalI = i;

                tableRow1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent I = new Intent(getApplicationContext(), AlterTable.class);
                        I.putExtra("mapa", (Serializable) mapa);
                        I.putExtra("igra", finalI);
                        startActivity(I);
                    }
                });
            }
        }
        List<Integer> suma = new ArrayList<Integer>();
        suma.add(sum1);
        suma.add(sum2);
        suma.add(sum3);
        suma.add(sum4);

        final int id = i;
        TableRow t2 = new TableRow(this);
        for(Integer k: suma){
            TextView t3 = new TextView(this);
            t3.setGravity(1);
            t3.setText(String.valueOf(k));
            t3.setTextSize(28);

            t2.addView(t3);

        }
        t1.addView(t2);

        Button next = new Button(this);
        next = findViewById(R.id.nextButton);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(getApplicationContext(), AlterTable.class);
                I.putExtra("mapa", (Serializable) mapa);
                I.putExtra("igra", id);
                startActivity(I);
            }
        });
    }
}
