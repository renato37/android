package com.example.lorablok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class MainActivity extends AppCompatActivity {
    Map<String, List<String>> mapa = new HashMap<>();
    List<String> lista = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LinearLayout linearLayout = new LinearLayout(this);
    }


    public void buttonOk(View view) {
        EditText Ig1 = (EditText) findViewById(R.id.P1);
        EditText Ig2 = (EditText) findViewById(R.id.P2);
        EditText Ig3 = (EditText) findViewById(R.id.P3);
        EditText Ig4 = (EditText) findViewById(R.id.P4);


        mapa.put(Ig1.getText().toString(), lista);
        mapa.put(Ig2.getText().toString(), lista);
        mapa.put(Ig3.getText().toString(), lista);
        mapa.put(Ig4.getText().toString(), lista);
        Intent I = new Intent(getApplicationContext(), MainTable.class);
        I.putExtra("mapa", (Serializable) mapa);
        startActivity(I);
    }
}
