package hr;

public class Igra {
    Integer igraId;
    String naziv;
    Integer min;
    Integer max;
    Integer num;

    public Igra(Integer igraId){
        this.igraId = igraId;
        switch (igraId%7) {
            case 0:
                this.naziv = "Što više";
                this.max = -8;
                this.min = -8;
                this.num = -1;
                break;
            case 1:
                this.naziv = "Što manje";
                this.max = 8;
                this.min = 8;
                this.num = 1;
                break;
            case 2:
                this.naziv = "Babe";
                this.max = 8;
                this.min = 8;
                this.num = 2;
                break;
            case 3:
                this.naziv = "Crvene";
                this.max = 8;
                this.min = 8;
                this.num = 1;
                break;
            case 4:
                this.naziv = "Crveni kralj, zadnji štih";
                this.max = 8;
                this.min = 8;
                this.num = 4;
                break;
            case 5:
                this.naziv = "Predviđanje";
                this.max = 32;
                this.min = 8;
                this.num = 8;
                break;
            case 6:
                this.naziv = "Lora";
                this.max = 60;
                this.min = 0;
                this.num = 1;
                break;
        }
    }
    public Integer getIgraId() {
        return igraId;
    }

    public String getNaziv() {
        return naziv;
    }

    public Integer getMin() {
        return min;
    }

    public Integer getMax() {
        return max;
    }

    public Integer getNum() { return num; }
}
